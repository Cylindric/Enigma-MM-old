Minecraft Server Manager
========================
Enigma Minecraft Manager is designed to help run and manage a Minecraft Alpha multi-player server.  EMM is a wrapper that allows the administrator to manage the server in ways not readily available using the standard interface, and to do so remotely if desired.

EMM does not modify the server in any way, in fact you have to download the server yourself as I can't distribute it.   That does also mean that you can use a modded server if you want, such as Hey0's hMod, because you can configure which jar to launch.

See the Wiki for documentation

http://github.com/Cylindric/Enigma-MM/wiki
